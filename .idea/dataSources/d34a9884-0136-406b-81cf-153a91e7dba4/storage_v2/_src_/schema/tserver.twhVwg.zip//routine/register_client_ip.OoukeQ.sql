create
    definer = root@localhost procedure register_client_ip(IN p_mac varchar(127), IN p_ip varchar(127))
BEGIN

	UPDATE front_client SET ip_addr = p_ip
	WHERE mac = p_mac;

END;

