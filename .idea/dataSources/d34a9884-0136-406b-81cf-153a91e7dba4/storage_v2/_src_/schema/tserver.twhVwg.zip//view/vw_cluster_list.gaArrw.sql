create view vw_cluster_list as
select `tserver`.`front_cluster`.`cluster_id`   AS `cluster_id`,
       `tserver`.`front_cluster`.`cluster_name` AS `cluster_name`
from `tserver`.`front_cluster`;

