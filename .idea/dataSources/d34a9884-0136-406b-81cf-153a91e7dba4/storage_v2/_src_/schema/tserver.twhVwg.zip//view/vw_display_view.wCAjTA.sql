create view vw_display_view as
select `vw_front_event`.`event_name`          AS `event_name`,
       `vw_front_event`.`cluster_name`        AS `cluster_name`,
       `vw_front_event`.`date`                AS `date`,
       `vw_front_event`.`time`                AS `time`,
       `vw_front_event`.`activate`            AS `activate`,
       `vw_front_event`.`machine_group`       AS `machine_group`,
       `tserver`.`front_action`.`time_offset` AS `time_offset`,
       `vw_front_event`.`event_id`            AS `event_id`,
       `vw_front_event`.`group_id`            AS `group_id`
from (`tserver`.`vw_front_event`
         join `tserver`.`front_action` on (((`vw_front_event`.`cluster_id` = `tserver`.`front_action`.`cluster_id`) and
                                            (`vw_front_event`.`activate` = `tserver`.`front_action`.`activate`) and
                                            (`vw_front_event`.`event_id` = `tserver`.`front_action`.`event_id`) and
                                            (`vw_front_event`.`action_id` = `tserver`.`front_action`.`action_id`))));

