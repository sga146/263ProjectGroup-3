create
    definer = root@localhost procedure next_event_id()
BEGIN
	SELECT MAX(event_id) FROM tserver.front_event;
END;

