create
    definer = root@localhost procedure add_daily(IN id int, IN group_id varchar(255), IN day int, IN start time)
BEGIN
	insert into front_daily (event_id, group_id, day_of_week, start_time) values (id, group_id, day, start);
END;

