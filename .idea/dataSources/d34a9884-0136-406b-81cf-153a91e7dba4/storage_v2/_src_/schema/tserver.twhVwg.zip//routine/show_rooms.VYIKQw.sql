create
    definer = root@localhost procedure show_rooms()
BEGIN
	SELECT room_name FROM front_room ORDER BY room_name;
END;

