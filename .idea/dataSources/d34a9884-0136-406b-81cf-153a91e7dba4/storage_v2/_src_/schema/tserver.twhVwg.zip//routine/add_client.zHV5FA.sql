create
    definer = admin@localhost procedure add_client(IN p_room_name varchar(127), IN p_group_name varchar(127),
                                                   IN p_mac varchar(127), IN p_serial_no varchar(127),
                                                   IN p_position int unsigned)
BEGIN
	INSERT INTO front_client (mac, group_id, room_id, serial_no, position)
	VALUES (
		p_mac,
		(SELECT group_id FROM front_group WHERE machine_group = p_group_name),
		(SELECT room_id FROM front_room WHERE room_name = p_room_name),
		p_serial_no, p_position);
END;

