create
    definer = root@localhost procedure show_room_clients(IN p_room_name varchar(127))
BEGIN
        SELECT mac, serial_no, position
	FROM vw_front_group_client
	WHERE room_name = p_room_name
	ORDER BY position;
END;

