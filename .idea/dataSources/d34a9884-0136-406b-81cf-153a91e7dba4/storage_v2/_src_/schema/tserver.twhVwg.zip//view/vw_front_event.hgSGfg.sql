create view vw_front_event as
select `e`.`event_name`                                                                             AS `event_name`,
       `fc`.`cluster_name`                                                                          AS `cluster_name`,
       `fc`.`cluster_id`                                                                            AS `cluster_id`,
       `g`.`machine_group`                                                                          AS `machine_group`,
       `g`.`group_id`                                                                               AS `group_id`,
       str_to_date(concat(`fw`.`event_year`, ' ', `fw`.`week_of_year`, ' ', `w`.`day`), '%x %v %W') AS `date`,
       addtime(`d`.`start_time`, `a`.`time_offset`)                                                 AS `time`,
       `a`.`activate`                                                                               AS `activate`,
       `e`.`event_id`                                                                               AS `event_id`,
       `a`.`action_id`                                                                              AS `action_id`,
       `d`.`daily_id`                                                                               AS `daily_id`,
       `fw`.`weekly_id`                                                                             AS `weekly_id`,
       `el`.`status`                                                                                AS `status`,
       `el`.`ran`                                                                                   AS `date_ran`
from (((((((`tserver`.`front_event` `e` join `tserver`.`front_daily` `d` on ((`e`.`event_id` = `d`.`event_id`))) join `tserver`.`front_group` `g` on ((`d`.`group_id` = `g`.`group_id`))) join `tserver`.`front_day_of_week` `w` on ((`d`.`day_of_week` = `w`.`day_of_week`))) join `tserver`.`front_action` `a` on ((`e`.`event_id` = `a`.`event_id`))) join `tserver`.`front_cluster` `fc` on ((`a`.`cluster_id` = `fc`.`cluster_id`))) join `tserver`.`front_weekly` `fw` on ((`e`.`event_id` = `fw`.`event_id`)))
         left join `tserver`.`front_event_log` `el`
                   on (((`e`.`event_id` = `el`.`event_id`) and (`a`.`action_id` = `el`.`action_id`) and
                        (`d`.`daily_id` = `el`.`daily_id`) and (`fw`.`weekly_id` = `el`.`weekly_id`))))
order by `fw`.`week_of_year`, `d`.`day_of_week`, addtime(`d`.`start_time`, `a`.`time_offset`), `g`.`machine_group`;

