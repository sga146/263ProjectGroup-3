create
    definer = root@localhost procedure add_event_week(IN name varchar(255), IN id int, IN week int, IN year int)
BEGIN
	insert into front_event (event_name, status) values (name, 1);
    insert into front_weekly (event_id, week_of_year, event_year) values (id, week, year);
END;

