create view vw_machine_list as
select `tserver`.`front_group`.`group_id` AS `group_id`, `tserver`.`front_group`.`machine_group` AS `machine_group`
from `tserver`.`front_group`;

