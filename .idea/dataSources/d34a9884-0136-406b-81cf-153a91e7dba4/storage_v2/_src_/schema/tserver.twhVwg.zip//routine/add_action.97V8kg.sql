create
    definer = root@localhost procedure add_action(IN id int, IN cluster int, IN offset time, IN length time)
BEGIN
	insert into front_action (event_id, time_offset, cluster_id, activate) values (id, offset, 3, 0);
    insert into front_action (event_id, time_offset, cluster_id, activate) values (id, offset, cluster, 1);
    insert into front_action (event_id, time_offset, cluster_id, activate) values (id, length, cluster, 0);
    insert into front_action (event_id, time_offset, cluster_id, activate) values (id, length, 3, 1);
END;

