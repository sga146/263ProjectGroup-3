create view vw_front_group_client as
select `r`.`room_name` AS `room_name`, `c`.`mac` AS `mac`, `c`.`serial_no` AS `serial_no`, `c`.`position` AS `position`
from ((`tserver`.`front_client` `c` join `tserver`.`front_room` `r` on ((`c`.`room_id` = `r`.`room_id`)))
         join `tserver`.`front_group` `g` on ((`c`.`group_id` = `g`.`group_id`)))
order by `r`.`room_name`, `c`.`position`;

