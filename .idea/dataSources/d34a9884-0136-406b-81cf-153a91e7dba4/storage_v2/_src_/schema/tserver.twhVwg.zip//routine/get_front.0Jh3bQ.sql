create
    definer = cluster_admin@localhost procedure get_front(IN mac_address char(17))
BEGIN

SET @mac = LOWER(mac_address);

SET @sql = CONCAT('( ',
                  'SELECT mac ',
                  '     , machine_group ',
                  '     , version ',
                  '     , config ' ,
                  '     , message ',
                  '     , 1 AS has_config ',
                  'FROM vw_front_clients ',
                  'WHERE mac = ? ',
                  ') ',
                  'UNION ',
                  '( ',
                  'SELECT ? AS mac ',
                  '     , machine_group ',
                  '     , config ' ,
                  '     , message ',
                  '     , 0 AS has_config ',
                  'FROM vw_front_groups ',
                  'WHERE machine_group = \'Default\' ',
                  ') ',
                  'LIMIT 1 ',
                  ';');
PREPARE userStmt FROM @sql;
EXECUTE userStmt USING @mac, @mac;
DEALLOCATE PREPARE userStmt;

END;

