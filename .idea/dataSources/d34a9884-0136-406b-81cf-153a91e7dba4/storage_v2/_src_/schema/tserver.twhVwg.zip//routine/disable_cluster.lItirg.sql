create
    definer = admin@localhost procedure disable_cluster(IN in_cluster_name char(128), IN in_machine_group char(100))
BEGIN
        update front_cluster_instance ci
        join front_cluster c on ci.cluster_id = c.cluster_id
        join front_group g on ci.group_id = g.group_id
        set active = 0 where cluster_name = in_cluster_name
        and machine_group = in_machine_group;

END;

